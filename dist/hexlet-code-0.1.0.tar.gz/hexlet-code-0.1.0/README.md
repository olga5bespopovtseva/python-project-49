### Hexlet tests and linter status:
[![Actions Status](https://github.com/olga5bespopovtseva/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/olga5bespopovtseva/python-project-49/actions)
<a href="https://codeclimate.com/github/olga5bespopovtseva/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/97e52eb4a5d92ec18dc7/maintainability" /></a>

brain-even: https://asciinema.org/a/qstovkm2xZK4YlP4RrU4rbtXo

brain-calc:

brain-gcd: https://asciinema.org/a/oYa0URyODXegmBkMAU71PCAWo


