### Hexlet tests and linter status:
[![Actions Status](https://github.com/olga5bespopovtseva/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/olga5bespopovtseva/python-project-49/actions)
<a href="https://codeclimate.com/github/olga5bespopovtseva/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/97e52eb4a5d92ec18dc7/maintainability" /></a>

brain-even: https://asciinema.org/a/qstovkm2xZK4YlP4RrU4rbtXo

brain-calc: https://asciinema.org/a/LFwh7feLM9xdYIr5kWiupyhER 

brain-gcd: https://asciinema.org/a/oYa0URyODXegmBkMAU71PCAWo

brain-progression: https://asciinema.org/a/MPs7SdTME7cVlyVmiR31YrTK6

brain-prime: https://asciinema.org/a/1LirSBpcWkCoodZa1q59x5G4N
