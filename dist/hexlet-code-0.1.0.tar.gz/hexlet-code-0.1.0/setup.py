# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '5 different Brain Games based on mathematical calcuations.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/olga5bespopovtseva/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/olga5bespopovtseva/python-project-49/actions)\n<a href="https://codeclimate.com/github/olga5bespopovtseva/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/97e52eb4a5d92ec18dc7/maintainability" /></a>\n\nThis is a first Hexlet project for python3. You will need to install some necesary tools:\n\npython = "^3.10"\n\nprompt = "^0.4.1"\n\nThere are 5 games based on math calculations that will run with these commands putting them into the python-project-49 directory: brain-even, brain-calc, brain-gcd, brain-progression and brain-prime.\nTo install the package you will need to run \'make package-install\': python3 -m pip install --user --force-reinstall dist/*.whl\n\n\nDemos:\n\nbrain-even: https://asciinema.org/a/qstovkm2xZK4YlP4RrU4rbtXo\n\nbrain-calc: https://asciinema.org/a/QyuGOGMvJbhYcNY9F8CA7whNT \n\nbrain-gcd: https://asciinema.org/a/oYa0URyODXegmBkMAU71PCAWo\n\nbrain-progression: https://asciinema.org/a/MPs7SdTME7cVlyVmiR31YrTK6\n\nbrain-prime: https://asciinema.org/a/1LirSBpcWkCoodZa1q59x5G4N\n',
    'author': 'Olga5',
    'author_email': 'olinkaa@hotmail.es',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
