# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/olga5bespopovtseva/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/olga5bespopovtseva/python-project-49/actions)\n<a href="https://codeclimate.com/github/olga5bespopovtseva/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/97e52eb4a5d92ec18dc7/maintainability" /></a>\n\nbrain-even: https://asciinema.org/a/qstovkm2xZK4YlP4RrU4rbtXo\n\nbrain-calc: https://asciinema.org/a/LFwh7feLM9xdYIr5kWiupyhER \n\nbrain-gcd: https://asciinema.org/a/oYa0URyODXegmBkMAU71PCAWo\n\nbrain-progression: https://asciinema.org/a/MPs7SdTME7cVlyVmiR31YrTK6\n\nbrain-prime: https://asciinema.org/a/1LirSBpcWkCoodZa1q59x5G4N\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
